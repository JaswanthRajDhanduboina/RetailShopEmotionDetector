import React, { useState, useEffect } from 'react';
import { Camera, Users, TrendingUp, AlertTriangle, Settings, BarChart3, Eye, UserCheck, Clock, Wifi } from 'lucide-react';
import CameraFeed from './components/CameraFeed';
import EmotionPanel from './components/EmotionPanel';
import CustomerFlow from './components/CustomerFlow';
import PerformanceMetrics from './components/PerformanceMetrics';
import AlertsPanel from './components/AlertsPanel';
import AnnotationInterface from './components/AnnotationInterface';

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isSystemActive, setIsSystemActive] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [cameraPermission, setCameraPermission] = useState<'granted' | 'denied' | 'prompt'>('prompt');

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Check camera permissions on load
  useEffect(() => {
    navigator.permissions.query({ name: 'camera' as PermissionName }).then((result) => {
      setCameraPermission(result.state as 'granted' | 'denied' | 'prompt');
    }).catch(() => {
      // Fallback for browsers that don't support permissions API
      setCameraPermission('prompt');
    });
  }, []);

  const requestCameraPermission = async () => {
    try {
      await navigator.mediaDevices.getUserMedia({ video: true });
      setCameraPermission('granted');
      setIsSystemActive(true);
    } catch (error) {
      setCameraPermission('denied');
      console.error('Camera permission denied:', error);
    }
  };

  const tabs = [
    { id: 'dashboard', label: 'Live Dashboard', icon: BarChart3 },
    { id: 'analysis', label: 'Emotion Analysis', icon: Eye },
    { id: 'customers', label: 'Customer Flow', icon: Users },
    { id: 'annotation', label: 'Data Annotation', icon: UserCheck },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Header */}
      <header className="bg-gray-800 border-b border-gray-700">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                <Camera className="h-6 w-6" />
              </div>
              <div>
                <h1 className="text-xl font-bold">RetailMind AI</h1>
                <p className="text-sm text-gray-400">Real-time Emotion Detection System</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-6">
              <div className="flex items-center space-x-2">
                <Wifi className={`w-3 h-3 ${cameraPermission === 'granted' ? 'text-green-500' : 'text-red-500'}`} />
                <span className="text-sm text-gray-300">
                  Camera: {cameraPermission === 'granted' ? 'Connected' : 'Not Connected'}
                </span>
              </div>
              
              <div className="flex items-center space-x-2">
                <div className={`w-3 h-3 rounded-full ${isSystemActive ? 'bg-green-500' : 'bg-red-500'} animate-pulse`}></div>
                <span className="text-sm text-gray-300">{isSystemActive ? 'System Active' : 'System Offline'}</span>
              </div>
              
              <div className="flex items-center space-x-2 text-sm text-gray-300">
                <Clock className="h-4 w-4" />
                <span>{currentTime.toLocaleTimeString()}</span>
              </div>
              
              {cameraPermission === 'denied' && (
                <button
                  onClick={requestCameraPermission}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors"
                >
                  Enable Camera
                </button>
              )}
              
              {cameraPermission === 'granted' && (
                <button
                  onClick={() => setIsSystemActive(!isSystemActive)}
                  className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                    isSystemActive 
                      ? 'bg-red-600 hover:bg-red-700 text-white' 
                      : 'bg-green-600 hover:bg-green-700 text-white'
                  }`}
                >
                  {isSystemActive ? 'Stop System' : 'Start System'}
                </button>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-gray-800 border-b border-gray-700">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex space-x-1">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center space-x-2 px-4 py-3 font-medium text-sm rounded-t-lg transition-colors ${
                    activeTab === tab.id
                      ? 'bg-gray-900 text-blue-400 border-b-2 border-blue-400'
                      : 'text-gray-400 hover:text-gray-200 hover:bg-gray-700'
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-6 py-8">
        {/* Camera Permission Alert */}
        {cameraPermission === 'denied' && (
          <div className="mb-8 bg-red-900/20 border border-red-700 rounded-lg p-4">
            <div className="flex items-center space-x-3">
              <AlertTriangle className="h-5 w-5 text-red-500" />
              <div>
                <h3 className="font-medium text-red-200">Camera Access Required</h3>
                <p className="text-sm text-red-300">
                  This application requires camera access to detect and analyze customer emotions. 
                  Please enable camera permissions in your browser settings.
                </p>
              </div>
              <button
                onClick={requestCameraPermission}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg font-medium transition-colors"
              >
                Enable Camera
              </button>
            </div>
          </div>
        )}

        {activeTab === 'dashboard' && (
          <div className="space-y-8">
            {/* System Status Alert */}
            {!isSystemActive && cameraPermission === 'granted' && (
              <div className="bg-amber-900/20 border border-amber-700 rounded-lg p-4">
                <div className="flex items-center space-x-3">
                  <AlertTriangle className="h-5 w-5 text-amber-500" />
                  <div>
                    <h3 className="font-medium text-amber-200">System Inactive</h3>
                    <p className="text-sm text-amber-300">Emotion detection is currently disabled. Click "Start System" to begin monitoring.</p>
                  </div>
                </div>
              </div>
            )}

            {/* Camera Feeds */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <CameraFeed 
                title="Entry Point Camera" 
                location="Main Entrance" 
                isActive={isSystemActive && cameraPermission === 'granted'}
                type="entry"
              />
              <CameraFeed 
                title="Exit Point Camera" 
                location="Main Exit" 
                isActive={isSystemActive && cameraPermission === 'granted'}
                type="exit"
              />
            </div>

            {/* Real-time Metrics */}
            <PerformanceMetrics />

            {/* Alerts */}
            <AlertsPanel />
          </div>
        )}

        {activeTab === 'analysis' && (
          <div className="space-y-8">
            <EmotionPanel isActive={isSystemActive && cameraPermission === 'granted'} />
          </div>
        )}

        {activeTab === 'customers' && (
          <div className="space-y-8">
            <CustomerFlow isActive={isSystemActive && cameraPermission === 'granted'} />
          </div>
        )}

        {activeTab === 'annotation' && (
          <div className="space-y-8">
            <AnnotationInterface />
          </div>
        )}

        {activeTab === 'settings' && (
          <div className="space-y-8">
            <div className="bg-gray-800 rounded-lg p-6">
              <h2 className="text-xl font-bold mb-4">System Configuration</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h3 className="font-medium text-gray-300">Camera Settings</h3>
                  <div className="space-y-3">
                    <label className="flex items-center justify-between">
                      <span className="text-sm">Camera Resolution</span>
                      <select className="px-3 py-1 bg-gray-700 rounded text-sm">
                        <option>640x480</option>
                        <option>1280x720</option>
                        <option>1920x1080</option>
                      </select>
                    </label>
                    <label className="flex items-center justify-between">
                      <span className="text-sm">Frame Rate</span>
                      <select className="px-3 py-1 bg-gray-700 rounded text-sm">
                        <option>15 FPS</option>
                        <option>30 FPS</option>
                        <option>60 FPS</option>
                      </select>
                    </label>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <h3 className="font-medium text-gray-300">Detection Settings</h3>
                  <div className="space-y-3">
                    <label className="flex items-center justify-between">
                      <span className="text-sm">Face Detection Confidence</span>
                      <input type="range" min="0.1" max="1" step="0.1" defaultValue="0.7" className="w-24" />
                    </label>
                    <label className="flex items-center justify-between">
                      <span className="text-sm">Emotion Classification Threshold</span>
                      <input type="range" min="0.1" max="1" step="0.1" defaultValue="0.8" className="w-24" />
                    </label>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <h3 className="font-medium text-gray-300">Alert Thresholds</h3>
                  <div className="space-y-3">
                    <label className="flex items-center justify-between">
                      <span className="text-sm">Negative Emotion Alert (%)</span>
                      <input type="number" min="0" max="100" defaultValue="30" className="w-16 px-2 py-1 bg-gray-700 rounded text-sm" />
                    </label>
                    <label className="flex items-center justify-between">
                      <span className="text-sm">Customer Flow Alert (per hour)</span>
                      <input type="number" min="0" defaultValue="50" className="w-16 px-2 py-1 bg-gray-700 rounded text-sm" />
                    </label>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="font-medium text-gray-300">Privacy Settings</h3>
                  <div className="space-y-3">
                    <label className="flex items-center space-x-2">
                      <input type="checkbox" defaultChecked className="rounded" />
                      <span className="text-sm">Store detection data locally</span>
                    </label>
                    <label className="flex items-center space-x-2">
                      <input type="checkbox" className="rounded" />
                      <span className="text-sm">Enable face recognition</span>
                    </label>
                    <label className="flex items-center space-x-2">
                      <input type="checkbox" defaultChecked className="rounded" />
                      <span className="text-sm">Auto-delete data after 30 days</span>
                    </label>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

export default App;