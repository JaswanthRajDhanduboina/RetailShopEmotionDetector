import React, { useState } from 'react';
import { Image, Tag, Save, Upload, Download, Trash2, Eye, Edit3 } from 'lucide-react';

interface Annotation {
  id: string;
  imageUrl: string;
  faces: Array<{
    id: string;
    x: number;
    y: number;
    width: number;
    height: number;
    emotion: string;
    confidence: number;
  }>;
  timestamp: Date;
  annotator: string;
  status: 'pending' | 'completed' | 'reviewed';
}

const AnnotationInterface: React.FC = () => {
  const [annotations, setAnnotations] = useState<Annotation[]>([
    {
      id: '1',
      imageUrl: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=400',
      faces: [
        { id: 'f1', x: 120, y: 80, width: 80, height: 100, emotion: 'happy', confidence: 0.92 },
        { id: 'f2', x: 250, y: 90, width: 75, height: 95, emotion: 'neutral', confidence: 0.87 }
      ],
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
      annotator: 'AI System',
      status: 'pending'
    },
    {
      id: '2',
      imageUrl: 'https://images.pexels.com/photos/1065084/pexels-photo-1065084.jpeg?auto=compress&cs=tinysrgb&w=400',
      faces: [
        { id: 'f3', x: 180, y: 70, width: 85, height: 105, emotion: 'surprised', confidence: 0.78 }
      ],
      timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000),
      annotator: 'Manual Review',
      status: 'completed'
    }
  ]);

  const [selectedAnnotation, setSelectedAnnotation] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'list' | 'annotate'>('list');

  const emotions = ['happy', 'sad', 'angry', 'surprised', 'fearful', 'disgusted', 'neutral'];
  const emotionColors = {
    happy: 'border-green-500 bg-green-500/20',
    sad: 'border-blue-500 bg-blue-500/20',
    angry: 'border-red-500 bg-red-500/20',
    surprised: 'border-yellow-500 bg-yellow-500/20',
    fearful: 'border-purple-500 bg-purple-500/20',
    disgusted: 'border-orange-500 bg-orange-500/20',
    neutral: 'border-gray-500 bg-gray-500/20'
  };

  const getStatusColor = (status: Annotation['status']) => {
    switch (status) {
      case 'pending': return 'text-yellow-400 bg-yellow-900/20';
      case 'completed': return 'text-green-400 bg-green-900/20';
      case 'reviewed': return 'text-blue-400 bg-blue-900/20';
      default: return 'text-gray-400 bg-gray-900/20';
    }
  };

  const updateAnnotationStatus = (id: string, status: Annotation['status']) => {
    setAnnotations(prev => prev.map(ann => 
      ann.id === id ? { ...ann, status } : ann
    ));
  };

  const deleteAnnotation = (id: string) => {
    setAnnotations(prev => prev.filter(ann => ann.id !== id));
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Data Annotation Interface</h2>
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setViewMode('list')}
              className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                viewMode === 'list' 
                  ? 'bg-blue-600 text-white' 
                  : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
              }`}
            >
              <Tag className="h-4 w-4 inline mr-2" />
              List View
            </button>
            <button
              onClick={() => setViewMode('annotate')}
              className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                viewMode === 'annotate' 
                  ? 'bg-blue-600 text-white' 
                  : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
              }`}
            >
              <Edit3 className="h-4 w-4 inline mr-2" />
              Annotate
            </button>
          </div>
          
          <div className="flex items-center space-x-2">
            <button className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg font-medium transition-colors">
              <Upload className="h-4 w-4 inline mr-2" />
              Upload Images
            </button>
            <button className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors">
              <Download className="h-4 w-4 inline mr-2" />
              Export Data
            </button>
          </div>
        </div>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-gray-800 rounded-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Total Images</p>
              <p className="text-2xl font-bold text-blue-400">{annotations.length}</p>
            </div>
            <Image className="h-8 w-8 text-blue-400" />
          </div>
        </div>

        <div className="bg-gray-800 rounded-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Pending Review</p>
              <p className="text-2xl font-bold text-yellow-400">
                {annotations.filter(a => a.status === 'pending').length}
              </p>
            </div>
            <Eye className="h-8 w-8 text-yellow-400" />
          </div>
        </div>

        <div className="bg-gray-800 rounded-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Completed</p>
              <p className="text-2xl font-bold text-green-400">
                {annotations.filter(a => a.status === 'completed').length}
              </p>
            </div>
            <Tag className="h-8 w-8 text-green-400" />
          </div>
        </div>

        <div className="bg-gray-800 rounded-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Total Faces</p>
              <p className="text-2xl font-bold text-purple-400">
                {annotations.reduce((sum, ann) => sum + ann.faces.length, 0)}
              </p>
            </div>
            <Save className="h-8 w-8 text-purple-400" />
          </div>
        </div>
      </div>

      {viewMode === 'list' ? (
        /* List View */
        <div className="bg-gray-800 rounded-lg p-6">
          <h3 className="text-lg font-bold mb-4">Annotation Queue</h3>
          
          <div className="space-y-4">
            {annotations.map((annotation) => (
              <div key={annotation.id} className="bg-gray-700 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <img 
                      src={annotation.imageUrl} 
                      alt="Annotation" 
                      className="w-16 h-16 object-cover rounded-lg"
                    />
                    
                    <div>
                      <div className="flex items-center space-x-3 mb-2">
                        <h4 className="font-medium">Annotation #{annotation.id}</h4>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(annotation.status)}`}>
                          {annotation.status}
                        </span>
                      </div>
                      
                      <div className="text-sm text-gray-400 space-y-1">
                        <p>Faces detected: {annotation.faces.length}</p>
                        <p>Annotator: {annotation.annotator}</p>
                        <p>Timestamp: {annotation.timestamp.toLocaleString()}</p>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    {annotation.status === 'pending' && (
                      <>
                        <button
                          onClick={() => updateAnnotationStatus(annotation.id, 'completed')}
                          className="px-3 py-1 bg-green-600 hover:bg-green-700 text-white text-sm rounded transition-colors"
                        >
                          Approve
                        </button>
                        <button
                          onClick={() => setSelectedAnnotation(annotation.id)}
                          className="px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded transition-colors"
                        >
                          Edit
                        </button>
                      </>
                    )}
                    
                    <button
                      onClick={() => deleteAnnotation(annotation.id)}
                      className="px-3 py-1 bg-red-600 hover:bg-red-700 text-white text-sm rounded transition-colors"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>

                {/* Face annotations preview */}
                <div className="mt-4 flex flex-wrap gap-2">
                  {annotation.faces.map((face) => (
                    <div 
                      key={face.id}
                      className={`px-3 py-1 rounded-full text-xs font-medium border ${
                        emotionColors[face.emotion as keyof typeof emotionColors]
                      }`}
                    >
                      {face.emotion} ({(face.confidence * 100).toFixed(0)}%)
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        /* Annotation View */
        <div className="bg-gray-800 rounded-lg p-6">
          <h3 className="text-lg font-bold mb-4">Annotation Workspace</h3>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Image Canvas */}
            <div className="lg:col-span-2">
              <div className="bg-gray-900 rounded-lg p-4 min-h-96 flex items-center justify-center">
                <div className="text-center text-gray-500">
                  <Image className="h-16 w-16 mx-auto mb-4 opacity-50" />
                  <p className="text-lg mb-2">CVAT-Style Annotation Interface</p>
                  <p className="text-sm">Select an image to begin face and emotion annotation</p>
                  <p className="text-xs mt-2 text-gray-600">
                    Features: Bounding box drawing, emotion labeling, confidence scoring
                  </p>
                </div>
              </div>
            </div>

            {/* Annotation Tools */}
            <div className="space-y-6">
              <div>
                <h4 className="font-medium mb-3">Annotation Tools</h4>
                <div className="space-y-2">
                  <button className="w-full px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors">
                    Draw Bounding Box
                  </button>
                  <button className="w-full px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors">
                    Auto-Detect Faces
                  </button>
                  <button className="w-full px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition-colors">
                    Classify Emotions
                  </button>
                </div>
              </div>

              <div>
                <h4 className="font-medium mb-3">Emotion Labels</h4>
                <div className="grid grid-cols-2 gap-2">
                  {emotions.map((emotion) => (
                    <button
                      key={emotion}
                      className={`px-3 py-2 rounded-lg text-sm font-medium border-2 transition-colors ${
                        emotionColors[emotion as keyof typeof emotionColors]
                      } hover:opacity-80`}
                    >
                      {emotion}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <h4 className="font-medium mb-3">Training Data Export</h4>
                <div className="space-y-2">
                  <button className="w-full px-4 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded-lg transition-colors">
                    Export YOLO Format
                  </button>
                  <button className="w-full px-4 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded-lg transition-colors">
                    Export COCO Format
                  </button>
                  <button className="w-full px-4 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded-lg transition-colors">
                    Export CSV Data
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AnnotationInterface;