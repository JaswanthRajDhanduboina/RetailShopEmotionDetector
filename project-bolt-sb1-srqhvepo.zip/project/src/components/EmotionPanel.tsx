import React, { useState, useEffect } from 'react';
import { TrendingUp, TrendingDown, Minus, BarChart3, Users, Camera } from 'lucide-react';

interface EmotionPanelProps {
  isActive: boolean;
}

interface EmotionData {
  timestamp: Date;
  emotion: string;
  confidence: number;
  location: 'entry' | 'exit';
}

const EmotionPanel: React.FC<EmotionPanelProps> = ({ isActive }) => {
  const [emotionData, setEmotionData] = useState({
    happy: 45,
    neutral: 30,
    sad: 8,
    angry: 5,
    surprised: 7,
    fearful: 3,
    disgusted: 2
  });

  const [recentDetections, setRecentDetections] = useState<EmotionData[]>([]);
  const [satisfactionScore, setSatisfactionScore] = useState(0);
  const [trend, setTrend] = useState<'up' | 'down' | 'stable'>('stable');
  const [totalDetections, setTotalDetections] = useState(0);

  useEffect(() => {
    if (!isActive) return;

    const interval = setInterval(() => {
      // Simulate real-time emotion detection data
      const emotions = ['happy', 'neutral', 'sad', 'angry', 'surprised', 'fearful', 'disgusted'];
      const locations = ['entry', 'exit'] as const;
      
      // Add new detection
      if (Math.random() > 0.7) {
        const newDetection: EmotionData = {
          timestamp: new Date(),
          emotion: emotions[Math.floor(Math.random() * emotions.length)],
          confidence: Math.random() * 0.3 + 0.7,
          location: locations[Math.floor(Math.random() * locations.length)]
        };
        
        setRecentDetections(prev => [newDetection, ...prev.slice(0, 9)]);
        setTotalDetections(prev => prev + 1);
      }

      // Update emotion distribution
      setEmotionData(prev => ({
        happy: Math.max(0, Math.min(100, prev.happy + (Math.random() - 0.5) * 5)),
        neutral: Math.max(0, Math.min(100, prev.neutral + (Math.random() - 0.5) * 3)),
        sad: Math.max(0, Math.min(100, prev.sad + (Math.random() - 0.5) * 2)),
        angry: Math.max(0, Math.min(100, prev.angry + (Math.random() - 0.5) * 1)),
        surprised: Math.max(0, Math.min(100, prev.surprised + (Math.random() - 0.5) * 3)),
        fearful: Math.max(0, Math.min(100, prev.fearful + (Math.random() - 0.5) * 1)),
        disgusted: Math.max(0, Math.min(100, prev.disgusted + (Math.random() - 0.5) * 1))
      }));

      // Calculate satisfaction score based on positive emotions
      const positiveEmotions = emotionData.happy + emotionData.surprised;
      const negativeEmotions = emotionData.sad + emotionData.angry + emotionData.fearful + emotionData.disgusted;
      const newScore = Math.max(0, Math.min(100, (positiveEmotions / (positiveEmotions + negativeEmotions + emotionData.neutral)) * 100));
      setSatisfactionScore(newScore);

      // Determine trend
      if (newScore > 75) setTrend('up');
      else if (newScore < 60) setTrend('down');
      else setTrend('stable');
    }, 2000);

    return () => clearInterval(interval);
  }, [isActive, emotionData]);

  const emotions = [
    { name: 'Happy', value: emotionData.happy, color: 'bg-green-500', icon: '😊' },
    { name: 'Neutral', value: emotionData.neutral, color: 'bg-gray-500', icon: '😐' },
    { name: 'Sad', value: emotionData.sad, color: 'bg-blue-500', icon: '😢' },
    { name: 'Angry', value: emotionData.angry, color: 'bg-red-500', icon: '😠' },
    { name: 'Surprised', value: emotionData.surprised, color: 'bg-yellow-500', icon: '😲' },
    { name: 'Fearful', value: emotionData.fearful, color: 'bg-purple-500', icon: '😨' },
    { name: 'Disgusted', value: emotionData.disgusted, color: 'bg-orange-500', icon: '🤢' }
  ];

  const getTrendIcon = () => {
    switch (trend) {
      case 'up': return <TrendingUp className="h-5 w-5 text-green-500" />;
      case 'down': return <TrendingDown className="h-5 w-5 text-red-500" />;
      default: return <Minus className="h-5 w-5 text-gray-500" />;
    }
  };

  const getTrendColor = () => {
    switch (trend) {
      case 'up': return 'text-green-500';
      case 'down': return 'text-red-500';
      default: return 'text-gray-500';
    }
  };

  const getEmotionIcon = (emotion: string) => {
    const icons: { [key: string]: string } = {
      happy: '😊', neutral: '😐', sad: '😢', angry: '😠', 
      surprised: '😲', fearful: '😨', disgusted: '🤢'
    };
    return icons[emotion] || '😐';
  };

  return (
    <div className="space-y-6">
      {/* Real-time Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gray-800 rounded-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Total Detections</p>
              <p className="text-2xl font-bold text-blue-400">{totalDetections}</p>
            </div>
            <Camera className="h-8 w-8 text-blue-400" />
          </div>
        </div>

        <div className="bg-gray-800 rounded-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Active Cameras</p>
              <p className="text-2xl font-bold text-green-400">2</p>
            </div>
            <Users className="h-8 w-8 text-green-400" />
          </div>
        </div>

        <div className="bg-gray-800 rounded-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Detection Rate</p>
              <p className="text-2xl font-bold text-yellow-400">{(totalDetections / Math.max(1, Math.floor(Date.now() / 60000)) * 60).toFixed(1)}/min</p>
            </div>
            <BarChart3 className="h-8 w-8 text-yellow-400" />
          </div>
        </div>
      </div>

      {/* Satisfaction Score Card */}
      <div className="bg-gray-800 rounded-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold">Real-time Satisfaction Score</h2>
          <div className="flex items-center space-x-2">
            {getTrendIcon()}
            <span className={`font-medium ${getTrendColor()}`}>
              {trend === 'up' ? 'Improving' : trend === 'down' ? 'Declining' : 'Stable'}
            </span>
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <div className="text-4xl font-bold text-blue-400">
            {satisfactionScore.toFixed(1)}%
          </div>
          <div className="flex-1">
            <div className="w-full bg-gray-700 rounded-full h-3">
              <div 
                className="bg-gradient-to-r from-red-500 via-yellow-500 to-green-500 h-3 rounded-full transition-all duration-1000"
                style={{ width: `${satisfactionScore}%` }}
              ></div>
            </div>
            <div className="flex justify-between text-xs text-gray-400 mt-1">
              <span>Poor</span>
              <span>Good</span>
              <span>Excellent</span>
            </div>
          </div>
        </div>
      </div>

      {/* Live Emotion Detection Feed */}
      <div className="bg-gray-800 rounded-lg p-6">
        <h2 className="text-xl font-bold mb-4">Live Detection Feed</h2>
        <div className="space-y-3 max-h-64 overflow-y-auto">
          {recentDetections.length === 0 ? (
            <div className="text-center text-gray-500 py-4">
              <Camera className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">No recent detections</p>
              <p className="text-xs">Emotion detections will appear here in real-time</p>
            </div>
          ) : (
            recentDetections.map((detection, index) => (
              <div key={index} className="flex items-center justify-between bg-gray-700 rounded-lg p-3">
                <div className="flex items-center space-x-3">
                  <div className="text-2xl">{getEmotionIcon(detection.emotion)}</div>
                  <div>
                    <div className="font-medium capitalize">{detection.emotion}</div>
                    <div className="text-xs text-gray-400">
                      {detection.location} • {detection.timestamp.toLocaleTimeString()}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-sm font-medium">{(detection.confidence * 100).toFixed(0)}%</div>
                  <div className={`text-xs px-2 py-1 rounded-full ${
                    detection.location === 'entry' ? 'bg-green-900/50 text-green-400' : 'bg-blue-900/50 text-blue-400'
                  }`}>
                    {detection.location}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Emotion Distribution */}
      <div className="bg-gray-800 rounded-lg p-6">
        <div className="flex items-center space-x-3 mb-6">
          <BarChart3 className="h-6 w-6 text-blue-400" />
          <h2 className="text-xl font-bold">Live Emotion Distribution</h2>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
          {emotions.map((emotion) => (
            <div key={emotion.name} className="text-center">
              <div className="text-2xl mb-2">{emotion.icon}</div>
              <div className="w-full bg-gray-700 rounded-full h-2 mb-2">
                <div 
                  className={`${emotion.color} h-2 rounded-full transition-all duration-500`}
                  style={{ width: `${emotion.value}%` }}
                ></div>
              </div>
              <div className="text-sm font-medium">{emotion.name}</div>
              <div className="text-xs text-gray-400">{emotion.value.toFixed(1)}%</div>
            </div>
          ))}
        </div>
      </div>

      {/* Entry vs Exit Comparison */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-gray-800 rounded-lg p-6">
          <h3 className="text-lg font-bold mb-4 text-green-400">Entry Emotions (Live)</h3>
          <div className="space-y-3">
            {recentDetections.filter(d => d.location === 'entry').slice(0, 3).map((detection, index) => (
              <div key={index} className="flex justify-between items-center">
                <div className="flex items-center space-x-2">
                  <span className="text-lg">{getEmotionIcon(detection.emotion)}</span>
                  <span className="text-sm capitalize">{detection.emotion}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-16 bg-gray-700 rounded-full h-2">
                    <div className="bg-green-500 h-2 rounded-full" style={{ width: `${detection.confidence * 100}%` }}></div>
                  </div>
                  <span className="text-sm">{(detection.confidence * 100).toFixed(0)}%</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-gray-800 rounded-lg p-6">
          <h3 className="text-lg font-bold mb-4 text-blue-400">Exit Emotions (Live)</h3>
          <div className="space-y-3">
            {recentDetections.filter(d => d.location === 'exit').slice(0, 3).map((detection, index) => (
              <div key={index} className="flex justify-between items-center">
                <div className="flex items-center space-x-2">
                  <span className="text-lg">{getEmotionIcon(detection.emotion)}</span>
                  <span className="text-sm capitalize">{detection.emotion}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-16 bg-gray-700 rounded-full h-2">
                    <div className="bg-blue-500 h-2 rounded-full" style={{ width: `${detection.confidence * 100}%` }}></div>
                  </div>
                  <span className="text-sm">{(detection.confidence * 100).toFixed(0)}%</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmotionPanel;