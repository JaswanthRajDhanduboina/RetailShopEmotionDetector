import React, { useState, useEffect, useRef } from 'react';
import { Camera, Wifi, WifiOff, Users, AlertCircle, Play, Square } from 'lucide-react';

interface CameraFeedProps {
  title: string;
  location: string;
  isActive: boolean;
  type: 'entry' | 'exit';
}

const CameraFeed: React.FC<CameraFeedProps> = ({ title, location, isActive, type }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [detectedFaces, setDetectedFaces] = useState(0);
  const [currentEmotion, setCurrentEmotion] = useState<string | null>(null);
  const [confidence, setConfidence] = useState(0);
  const [isRecording, setIsRecording] = useState(false);

  const emotions = ['happy', 'neutral', 'sad', 'angry', 'surprised', 'fearful', 'disgusted'];
  const emotionColors = {
    happy: 'text-green-400',
    neutral: 'text-gray-400',
    sad: 'text-blue-400',
    angry: 'text-red-400',
    surprised: 'text-yellow-400',
    fearful: 'text-purple-400',
    disgusted: 'text-orange-400'
  };

  // Initialize camera
  const startCamera = async () => {
    try {
      setCameraError(null);
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 640 },
          height: { ideal: 480 },
          facingMode: 'user'
        },
        audio: false
      });
      
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
        videoRef.current.play();
        setIsRecording(true);
      }
    } catch (error) {
      console.error('Camera access error:', error);
      setCameraError('Unable to access camera. Please check permissions.');
    }
  };

  // Stop camera
  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
      setIsRecording(false);
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  };

  // Face detection simulation (placeholder for actual ML integration)
  const detectFaces = () => {
    if (!videoRef.current || !canvasRef.current || !isActive || !isRecording) return;

    const video = videoRef.current;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');

    if (!ctx) return;

    // Set canvas size to match video
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    // Draw current video frame
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

    // Simulate face detection (replace with actual ML model)
    const faceCount = Math.random() > 0.6 ? Math.floor(Math.random() * 3) + 1 : 0;
    setDetectedFaces(faceCount);

    if (faceCount > 0) {
      // Simulate emotion detection
      const emotion = emotions[Math.floor(Math.random() * emotions.length)];
      setCurrentEmotion(emotion);
      setConfidence(Math.random() * 0.3 + 0.7);

      // Draw bounding boxes (simulation)
      ctx.strokeStyle = '#3B82F6';
      ctx.lineWidth = 2;
      for (let i = 0; i < faceCount; i++) {
        const x = Math.random() * (canvas.width - 100);
        const y = Math.random() * (canvas.height - 120);
        ctx.strokeRect(x, y, 80, 100);
        
        // Draw emotion label
        ctx.fillStyle = '#3B82F6';
        ctx.font = '12px Arial';
        ctx.fillText(`${emotion} (${(confidence * 100).toFixed(0)}%)`, x, y - 5);
      }
    } else {
      setCurrentEmotion(null);
      setConfidence(0);
    }
  };

  // Start/stop camera based on system state
  useEffect(() => {
    if (isActive) {
      startCamera();
    } else {
      stopCamera();
    }

    return () => {
      stopCamera();
    };
  }, [isActive]);

  // Face detection interval
  useEffect(() => {
    if (!isActive || !isRecording) return;

    const interval = setInterval(detectFaces, 1000);
    return () => clearInterval(interval);
  }, [isActive, isRecording]);

  return (
    <div className="bg-gray-800 rounded-lg overflow-hidden">
      {/* Header */}
      <div className="p-4 border-b border-gray-700">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Camera className="h-5 w-5 text-gray-400" />
            <div>
              <h3 className="font-medium">{title}</h3>
              <p className="text-sm text-gray-400">{location}</p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            {isRecording ? (
              <Wifi className="h-4 w-4 text-green-500" />
            ) : (
              <WifiOff className="h-4 w-4 text-red-500" />
            )}
            <span className={`text-xs ${isRecording ? 'text-green-500' : 'text-red-500'}`}>
              {isRecording ? 'Live' : 'Offline'}
            </span>
          </div>
        </div>
      </div>

      {/* Camera Feed */}
      <div className="relative bg-gray-900 h-64">
        {cameraError ? (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center text-red-400">
              <AlertCircle className="h-12 w-12 mx-auto mb-2" />
              <p className="text-sm">{cameraError}</p>
              <button
                onClick={startCamera}
                className="mt-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm transition-colors"
              >
                Retry Camera Access
              </button>
            </div>
          </div>
        ) : (
          <>
            <video
              ref={videoRef}
              className="w-full h-full object-cover"
              autoPlay
              muted
              playsInline
            />
            <canvas
              ref={canvasRef}
              className="absolute inset-0 w-full h-full object-cover"
              style={{ mixBlendMode: 'multiply' }}
            />
            
            {!isRecording && isActive && (
              <div className="absolute inset-0 flex items-center justify-center bg-gray-900/50">
                <button
                  onClick={startCamera}
                  className="flex items-center space-x-2 px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors"
                >
                  <Play className="h-5 w-5" />
                  <span>Start Camera</span>
                </button>
              </div>
            )}

            {!isActive && (
              <div className="absolute inset-0 flex items-center justify-center bg-gray-900/80">
                <div className="text-center text-gray-500">
                  <Camera className="h-12 w-12 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">System Inactive</p>
                </div>
              </div>
            )}
          </>
        )}
      </div>

      {/* Detection Info */}
      <div className="p-4 space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-sm text-gray-400">Detected Faces</span>
          <span className="font-medium">{detectedFaces}</span>
        </div>
        
        {currentEmotion && (
          <>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-400">Primary Emotion</span>
              <span className={`font-medium capitalize ${emotionColors[currentEmotion as keyof typeof emotionColors]}`}>
                {currentEmotion}
              </span>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-400">Confidence</span>
              <span className="font-medium">{(confidence * 100).toFixed(1)}%</span>
            </div>
            
            <div className="w-full bg-gray-700 rounded-full h-2">
              <div 
                className="bg-blue-500 h-2 rounded-full transition-all duration-500"
                style={{ width: `${confidence * 100}%` }}
              ></div>
            </div>
          </>
        )}

        {type === 'entry' && detectedFaces > 0 && (
          <div className="flex items-center space-x-2 text-green-400 text-sm">
            <AlertCircle className="h-4 w-4" />
            <span>Customer entering store</span>
          </div>
        )}

        {type === 'exit' && detectedFaces > 0 && (
          <div className="flex items-center space-x-2 text-blue-400 text-sm">
            <AlertCircle className="h-4 w-4" />
            <span>Customer leaving store</span>
          </div>
        )}

        {/* Camera Controls */}
        <div className="flex items-center justify-between pt-2 border-t border-gray-700">
          <div className="text-xs text-gray-500">
            Camera: {stream ? 'Connected' : 'Disconnected'}
          </div>
          <div className="flex items-center space-x-2">
            {isRecording ? (
              <button
                onClick={stopCamera}
                className="flex items-center space-x-1 px-3 py-1 bg-red-600 hover:bg-red-700 text-white rounded text-xs transition-colors"
              >
                <Square className="h-3 w-3" />
                <span>Stop</span>
              </button>
            ) : (
              <button
                onClick={startCamera}
                className="flex items-center space-x-1 px-3 py-1 bg-green-600 hover:bg-green-700 text-white rounded text-xs transition-colors"
              >
                <Play className="h-3 w-3" />
                <span>Start</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CameraFeed;