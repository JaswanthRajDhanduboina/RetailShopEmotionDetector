import React, { useState, useEffect } from 'react';
import { AlertTriangle, CheckCircle, XCircle, Clock, Bell } from 'lucide-react';

interface Alert {
  id: string;
  type: 'warning' | 'error' | 'info' | 'success';
  title: string;
  message: string;
  timestamp: Date;
  resolved: boolean;
}

const AlertsPanel: React.FC = () => {
  const [alerts, setAlerts] = useState<Alert[]>([
    {
      id: '1',
      type: 'warning',
      title: 'High Negative Emotion Detected',
      message: 'Exit point showing 32% negative emotions in the last hour',
      timestamp: new Date(Date.now() - 15 * 60 * 1000),
      resolved: false
    },
    {
      id: '2',
      type: 'info',
      title: 'Peak Hours Detected',
      message: 'Customer flow is above average for this time period',
      timestamp: new Date(Date.now() - 45 * 60 * 1000),
      resolved: false
    },
    {
      id: '3',
      type: 'success',
      title: 'Satisfaction Target Met',
      message: 'Daily satisfaction score exceeded 85% target',
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
      resolved: true
    }
  ]);

  useEffect(() => {
    const interval = setInterval(() => {
      if (Math.random() > 0.8) {
        const alertTypes = ['warning', 'info', 'error'] as const;
        const messages = [
          { title: 'Camera Feed Issue', message: 'Entry camera experiencing intermittent connection issues' },
          { title: 'Unusual Emotion Pattern', message: 'Detecting higher than normal anxiety levels' },
          { title: 'System Performance', message: 'Emotion detection processing time increased' },
          { title: 'Customer Flow Alert', message: 'Unusual customer entry pattern detected' }
        ];
        
        const randomMessage = messages[Math.floor(Math.random() * messages.length)];
        const newAlert: Alert = {
          id: Date.now().toString(),
          type: alertTypes[Math.floor(Math.random() * alertTypes.length)],
          title: randomMessage.title,
          message: randomMessage.message,
          timestamp: new Date(),
          resolved: false
        };
        
        setAlerts(prev => [newAlert, ...prev.slice(0, 9)]);
      }
    }, 30000);

    return () => clearInterval(interval);
  }, []);

  const resolveAlert = (id: string) => {
    setAlerts(prev => prev.map(alert => 
      alert.id === id ? { ...alert, resolved: true } : alert
    ));
  };

  const dismissAlert = (id: string) => {
    setAlerts(prev => prev.filter(alert => alert.id !== id));
  };

  const getAlertIcon = (type: Alert['type']) => {
    switch (type) {
      case 'error': return <XCircle className="h-5 w-5 text-red-500" />;
      case 'warning': return <AlertTriangle className="h-5 w-5 text-yellow-500" />;
      case 'success': return <CheckCircle className="h-5 w-5 text-green-500" />;
      default: return <Bell className="h-5 w-5 text-blue-500" />;
    }
  };

  const getAlertBorderColor = (type: Alert['type']) => {
    switch (type) {
      case 'error': return 'border-l-red-500';
      case 'warning': return 'border-l-yellow-500';
      case 'success': return 'border-l-green-500';
      default: return 'border-l-blue-500';
    }
  };

  const activeAlerts = alerts.filter(alert => !alert.resolved);
  const resolvedAlerts = alerts.filter(alert => alert.resolved);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">System Alerts</h2>
        <div className="flex items-center space-x-2">
          <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
          <span className="text-sm text-gray-400">
            {activeAlerts.length} active alert{activeAlerts.length !== 1 ? 's' : ''}
          </span>
        </div>
      </div>

      {/* Active Alerts */}
      {activeAlerts.length > 0 && (
        <div className="bg-gray-800 rounded-lg p-6">
          <h3 className="text-lg font-bold mb-4 text-red-400">Active Alerts</h3>
          <div className="space-y-4">
            {activeAlerts.map((alert) => (
              <div key={alert.id} className={`bg-gray-700 rounded-lg p-4 border-l-4 ${getAlertBorderColor(alert.type)}`}>
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-3 flex-1">
                    {getAlertIcon(alert.type)}
                    <div className="flex-1">
                      <h4 className="font-medium text-gray-200">{alert.title}</h4>
                      <p className="text-sm text-gray-400 mt-1">{alert.message}</p>
                      <div className="flex items-center space-x-2 mt-2 text-xs text-gray-500">
                        <Clock className="h-3 w-3" />
                        <span>{alert.timestamp.toLocaleString()}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2 ml-4">
                    <button
                      onClick={() => resolveAlert(alert.id)}
                      className="px-3 py-1 bg-green-600 hover:bg-green-700 text-white text-xs rounded transition-colors"
                    >
                      Resolve
                    </button>
                    <button
                      onClick={() => dismissAlert(alert.id)}
                      className="px-3 py-1 bg-gray-600 hover:bg-gray-700 text-white text-xs rounded transition-colors"
                    >
                      Dismiss
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Resolved Alerts */}
      {resolvedAlerts.length > 0 && (
        <div className="bg-gray-800 rounded-lg p-6">
          <h3 className="text-lg font-bold mb-4 text-green-400">Recently Resolved</h3>
          <div className="space-y-3">
            {resolvedAlerts.slice(0, 3).map((alert) => (
              <div key={alert.id} className={`bg-gray-700/50 rounded-lg p-3 border-l-4 ${getAlertBorderColor(alert.type)} opacity-75`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    <div>
                      <h4 className="font-medium text-gray-300 text-sm">{alert.title}</h4>
                      <p className="text-xs text-gray-500">{alert.message}</p>
                    </div>
                  </div>
                  <button
                    onClick={() => dismissAlert(alert.id)}
                    className="px-2 py-1 bg-gray-600 hover:bg-gray-700 text-white text-xs rounded transition-colors"
                  >
                    Dismiss
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* No Alerts State */}
      {alerts.length === 0 && (
        <div className="bg-gray-800 rounded-lg p-8 text-center">
          <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-200 mb-2">All Clear</h3>
          <p className="text-gray-400">No system alerts at this time. All systems operating normally.</p>
        </div>
      )}
    </div>
  );
};

export default AlertsPanel;