import React, { useState, useEffect } from 'react';
import { TrendingUp, Users, Clock, Target, Star, AlertTriangle } from 'lucide-react';

const PerformanceMetrics: React.FC = () => {
  const [metrics, setMetrics] = useState({
    happinessIncrease: 12.5,
    customerThroughput: 34,
    averageDwellTime: 18.3,
    conversionRate: 67.2,
    satisfactionScore: 4.2,
    alertsToday: 3
  });

  useEffect(() => {
    const interval = setInterval(() => {
      setMetrics(prev => ({
        happinessIncrease: Math.max(0, prev.happinessIncrease + (Math.random() - 0.5) * 2),
        customerThroughput: Math.max(0, prev.customerThroughput + Math.floor((Math.random() - 0.5) * 5)),
        averageDwellTime: Math.max(5, prev.averageDwellTime + (Math.random() - 0.5) * 3),
        conversionRate: Math.max(0, Math.min(100, prev.conversionRate + (Math.random() - 0.5) * 5)),
        satisfactionScore: Math.max(1, Math.min(5, prev.satisfactionScore + (Math.random() - 0.5) * 0.2)),
        alertsToday: prev.alertsToday + (Math.random() > 0.9 ? 1 : 0)
      }));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const metricCards = [
    {
      title: 'Happiness Increase',
      value: `+${metrics.happinessIncrease.toFixed(1)}%`,
      icon: TrendingUp,
      color: 'text-green-400',
      bgColor: 'bg-green-900/20',
      description: 'Entry vs Exit emotion improvement'
    },
    {
      title: 'Customer Throughput',
      value: `${metrics.customerThroughput}/hr`,
      icon: Users,
      color: 'text-blue-400',
      bgColor: 'bg-blue-900/20',
      description: 'Current hourly customer flow'
    },
    {
      title: 'Average Dwell Time',
      value: `${metrics.averageDwellTime.toFixed(1)}m`,
      icon: Clock,
      color: 'text-yellow-400',
      bgColor: 'bg-yellow-900/20',
      description: 'Time spent in store'
    },
    {
      title: 'Engagement Rate',
      value: `${metrics.conversionRate.toFixed(1)}%`,
      icon: Target,
      color: 'text-purple-400',
      bgColor: 'bg-purple-900/20',
      description: 'Positive emotional engagement'
    },
    {
      title: 'Satisfaction Score',
      value: `${metrics.satisfactionScore.toFixed(1)}/5`,
      icon: Star,
      color: 'text-orange-400',
      bgColor: 'bg-orange-900/20',
      description: 'Overall customer satisfaction'
    },
    {
      title: 'Alerts Today',
      value: `${metrics.alertsToday}`,
      icon: AlertTriangle,
      color: 'text-red-400',
      bgColor: 'bg-red-900/20',
      description: 'System notifications and warnings'
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Performance Metrics</h2>
        <div className="text-sm text-gray-400">
          Last updated: {new Date().toLocaleTimeString()}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {metricCards.map((metric, index) => {
          const Icon = metric.icon;
          return (
            <div key={index} className={`bg-gray-800 rounded-lg p-6 border-l-4 border-l-${metric.color.split('-')[1]}-400`}>
              <div className="flex items-center justify-between mb-4">
                <div className={`p-3 rounded-lg ${metric.bgColor}`}>
                  <Icon className={`h-6 w-6 ${metric.color}`} />
                </div>
                <div className="text-right">
                  <div className={`text-2xl font-bold ${metric.color}`}>
                    {metric.value}
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="font-medium text-gray-200 mb-1">{metric.title}</h3>
                <p className="text-sm text-gray-400">{metric.description}</p>
              </div>

              {/* Progress indicator for some metrics */}
              {(metric.title.includes('Rate') || metric.title.includes('Score')) && (
                <div className="mt-4">
                  <div className="w-full bg-gray-700 rounded-full h-2">
                    <div 
                      className={`h-2 rounded-full transition-all duration-500 ${
                        metric.title.includes('Satisfaction') 
                          ? 'bg-orange-400' 
                          : 'bg-purple-400'
                      }`}
                      style={{ 
                        width: metric.title.includes('Satisfaction') 
                          ? `${(metrics.satisfactionScore / 5) * 100}%`
                          : `${metrics.conversionRate}%` 
                      }}
                    ></div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Trend Chart Placeholder */}
      <div className="bg-gray-800 rounded-lg p-6">
        <h3 className="text-lg font-bold mb-4">Emotion Trends (Last 24 Hours)</h3>
        <div className="h-64 bg-gray-700 rounded-lg flex items-center justify-center">
          <div className="text-center text-gray-500">
            <TrendingUp className="h-12 w-12 mx-auto mb-2 opacity-50" />
            <p className="text-sm">Real-time emotion trend visualization</p>
            <p className="text-xs text-gray-600">Chart integration would display here</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PerformanceMetrics;