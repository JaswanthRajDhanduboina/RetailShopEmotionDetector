import React, { useState, useEffect } from 'react';
import { Users, ArrowRight, Clock, TrendingUp, UserPlus, UserMinus } from 'lucide-react';

interface Customer {
  id: string;
  entryTime: Date;
  exitTime?: Date;
  entryEmotion: string;
  exitEmotion?: string;
  satisfactionChange: number;
  duration?: number;
}

interface CustomerFlowProps {
  isActive: boolean;
}

const CustomerFlow: React.FC<CustomerFlowProps> = ({ isActive }) => {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [currentCustomers, setCurrentCustomers] = useState(0);
  const [dailyVisitors, setDailyVisitors] = useState(247);
  const [averageStayTime, setAverageStayTime] = useState(18);

  const emotions = ['happy', 'neutral', 'sad', 'angry', 'surprised', 'anxious'];
  const emotionIcons = {
    happy: '😊',
    neutral: '😐',
    sad: '😢',
    angry: '😠',
    surprised: '😲',
    anxious: '😰'
  };

  useEffect(() => {
    if (!isActive) return;

    const interval = setInterval(() => {
      // Simulate new customer entry
      if (Math.random() > 0.7) {
        const newCustomer: Customer = {
          id: `customer_${Date.now()}`,
          entryTime: new Date(),
          entryEmotion: emotions[Math.floor(Math.random() * emotions.length)],
          satisfactionChange: 0
        };
        
        setCustomers(prev => [newCustomer, ...prev.slice(0, 19)]);
        setCurrentCustomers(prev => prev + 1);
        setDailyVisitors(prev => prev + 1);
      }

      // Simulate customer exit
      if (Math.random() > 0.6 && currentCustomers > 0) {
        setCustomers(prev => {
          const activeCustomers = prev.filter(c => !c.exitTime);
          if (activeCustomers.length > 0) {
            const exitingCustomer = activeCustomers[Math.floor(Math.random() * activeCustomers.length)];
            const exitEmotion = emotions[Math.floor(Math.random() * emotions.length)];
            const duration = Math.floor((Date.now() - exitingCustomer.entryTime.getTime()) / 60000) + Math.floor(Math.random() * 30);
            
            const entryScore = getEmotionScore(exitingCustomer.entryEmotion);
            const exitScore = getEmotionScore(exitEmotion);
            const satisfactionChange = exitScore - entryScore;

            return prev.map(c => 
              c.id === exitingCustomer.id 
                ? { ...c, exitTime: new Date(), exitEmotion, satisfactionChange, duration }
                : c
            );
          }
          return prev;
        });
        setCurrentCustomers(prev => Math.max(0, prev - 1));
      }
    }, 3000);

    return () => clearInterval(interval);
  }, [isActive, currentCustomers]);

  const getEmotionScore = (emotion: string): number => {
    const scores = { happy: 5, neutral: 3, surprised: 4, anxious: 2, sad: 1, angry: 0 };
    return scores[emotion as keyof typeof scores] || 3;
  };

  const getSatisfactionIcon = (change: number) => {
    if (change > 0) return <TrendingUp className="h-4 w-4 text-green-500" />;
    if (change < 0) return <TrendingUp className="h-4 w-4 text-red-500 rotate-180" />;
    return <ArrowRight className="h-4 w-4 text-gray-500" />;
  };

  const getSatisfactionColor = (change: number) => {
    if (change > 0) return 'text-green-500';
    if (change < 0) return 'text-red-500';
    return 'text-gray-500';
  };

  return (
    <div className="space-y-6">
      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-gray-800 rounded-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Currently In Store</p>
              <p className="text-2xl font-bold text-blue-400">{currentCustomers}</p>
            </div>
            <Users className="h-8 w-8 text-blue-400" />
          </div>
        </div>

        <div className="bg-gray-800 rounded-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Daily Visitors</p>
              <p className="text-2xl font-bold text-green-400">{dailyVisitors}</p>
            </div>
            <UserPlus className="h-8 w-8 text-green-400" />
          </div>
        </div>

        <div className="bg-gray-800 rounded-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Avg. Stay Time</p>
              <p className="text-2xl font-bold text-yellow-400">{averageStayTime}m</p>
            </div>
            <Clock className="h-8 w-8 text-yellow-400" />
          </div>
        </div>

        <div className="bg-gray-800 rounded-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Satisfaction Rate</p>
              <p className="text-2xl font-bold text-purple-400">
                {((customers.filter(c => c.satisfactionChange > 0).length / Math.max(customers.filter(c => c.exitTime).length, 1)) * 100).toFixed(0)}%
              </p>
            </div>
            <TrendingUp className="h-8 w-8 text-purple-400" />
          </div>
        </div>
      </div>

      {/* Customer Journey List */}
      <div className="bg-gray-800 rounded-lg p-6">
        <h2 className="text-xl font-bold mb-6">Recent Customer Journeys</h2>
        
        <div className="space-y-4">
          {customers.length === 0 ? (
            <div className="text-center text-gray-500 py-8">
              <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>No customer data available</p>
              <p className="text-sm">Customer journeys will appear here when the system is active</p>
            </div>
          ) : (
            customers.map((customer) => (
              <div key={customer.id} className="bg-gray-700 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-sm font-medium">
                      {customer.id.slice(-2)}
                    </div>
                    
                    <div className="flex items-center space-x-6">
                      <div className="text-center">
                        <div className="text-2xl mb-1">
                          {emotionIcons[customer.entryEmotion as keyof typeof emotionIcons]}
                        </div>
                        <div className="text-xs text-gray-400">Entry</div>
                        <div className="text-xs text-gray-300">
                          {customer.entryTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </div>
                      </div>

                      <ArrowRight className="h-5 w-5 text-gray-500" />

                      <div className="text-center">
                        {customer.exitTime ? (
                          <>
                            <div className="text-2xl mb-1">
                              {emotionIcons[customer.exitEmotion as keyof typeof emotionIcons]}
                            </div>
                            <div className="text-xs text-gray-400">Exit</div>
                            <div className="text-xs text-gray-300">
                              {customer.exitTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </div>
                          </>
                        ) : (
                          <>
                            <div className="text-2xl mb-1">⏳</div>
                            <div className="text-xs text-green-400">In Store</div>
                            <div className="text-xs text-gray-300">
                              {Math.floor((Date.now() - customer.entryTime.getTime()) / 60000)}m
                            </div>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center space-x-4">
                    {customer.exitTime && (
                      <>
                        <div className="text-center">
                          <div className="text-sm text-gray-400">Duration</div>
                          <div className="font-medium">{customer.duration}m</div>
                        </div>
                        
                        <div className="text-center">
                          <div className="text-sm text-gray-400">Satisfaction</div>
                          <div className={`flex items-center space-x-1 ${getSatisfactionColor(customer.satisfactionChange)}`}>
                            {getSatisfactionIcon(customer.satisfactionChange)}
                            <span className="font-medium">
                              {customer.satisfactionChange > 0 ? '+' : ''}
                              {customer.satisfactionChange}
                            </span>
                          </div>
                        </div>
                      </>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default CustomerFlow;